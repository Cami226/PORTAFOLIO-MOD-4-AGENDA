package clase;



import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

class AgendaTest {

    @Test
    void testAgregarTarea() {
        Agenda agenda = new Agenda();
        agenda.agregarTarea(new Tarea("Prueba", "10/10/2025"));

        assertEquals(1, agenda.listarTareas().size());
    }

    @Test
    void testFiltrarPendientes() {
        Agenda agenda = new Agenda();
        agenda.agregarTarea(new Tarea("Tarea 1", "01/01/2025"));
        agenda.agregarTarea(new Tarea("Tarea 2", "02/01/2025"));

        List<Tarea> pendientes = agenda.filtrarPorEstado(false);

        assertEquals(2, pendientes.size());
    }

    @Test
    void testMarcarComoCompletada() {
        Agenda agenda = new Agenda();
        Tarea t = new Tarea("Algo", "10/10/2025");
        agenda.agregarTarea(t);

        boolean resultado = agenda.marcarComoCompletada(t.getId());

        assertTrue(resultado);
        assertTrue(t.isCompletada());
    }
}
