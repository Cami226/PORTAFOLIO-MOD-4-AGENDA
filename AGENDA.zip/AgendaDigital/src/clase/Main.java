package clase;


import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Agenda agenda = new Agenda();
        Scanner scanner = new Scanner(System.in);

        int opcion;

        do {
            System.out.println("\n=== AGENDA DIGITAL ===");
            System.out.println("1. Agregar tarea");
            System.out.println("2. Listar tareas");
            System.out.println("3. Filtrar por estado");
            System.out.println("4. Marcar tarea como completada");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = scanner.nextInt();
            scanner.nextLine(); // limpiar buffer

            switch (opcion) {

                case 1:
                    System.out.print("Descripción: ");
                    String desc = scanner.nextLine();

                    System.out.print("Fecha (dd/mm/aaaa): ");
                    String fecha = scanner.nextLine();

                    agenda.agregarTarea(new Tarea(desc, fecha));
                    System.out.println("Tarea agregada.");
                    break;

                case 2:
                    System.out.println("\n--- TAREAS REGISTRADAS ---");
                    for (Tarea t : agenda.listarTareas()) {
                        System.out.println(t);
                    }
                    break;

                case 3:
                    System.out.println("\n1. Pendientes\n2. Completadas");
                    int est = scanner.nextInt();
                    boolean comp = est == 2;

                    for (Tarea t : agenda.filtrarPorEstado(comp)) {
                        System.out.println(t);
                    }
                    break;

                case 4:
                    System.out.print("Ingrese ID de la tarea: ");
                    int id = scanner.nextInt();

                    if (agenda.marcarComoCompletada(id)) {
                        System.out.println("Tarea marcada como completada.");
                    } else {
                        System.out.println("ID no encontrado.");
                    }
                    break;
            }

        } while (opcion != 5);

        scanner.close();
    }
}
