package clase;



public class Tarea {

    private static int contador = 1;

    private int id;
    private String descripcion;
    private String fecha;
    private boolean completada;

    public Tarea(String descripcion, String fecha) {
        this.id = contador++;
        this.descripcion = descripcion;
        this.fecha = fecha;
        this.completada = false;
    }

    public int getId() { return id; }

    public String getDescripcion() { 
    	return descripcion; 
    	
    }
    
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getFecha() { 
    	return fecha;
    	
    }
    
    public void setFecha(String fecha) { this.fecha = fecha; }

    public boolean isCompletada() { return completada; }

    public void marcarComoCompletada() {
        this.completada = true;
    }

    @Override
    public String toString() {
        return "Tarea ID: " + id +
                " | Descripción: " + descripcion +
                " | Fecha: " + fecha +
                " | Estado: " + (completada ? "Completada" : "Pendiente");
    }
}

