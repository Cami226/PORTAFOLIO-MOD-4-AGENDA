package clase;


import java.util.ArrayList;
import java.util.List;

public class Agenda {

    private List<Tarea> tareas = new ArrayList<>();

    public void agregarTarea(Tarea tarea) {
        tareas.add(tarea);
    }

    public List<Tarea> listarTareas() {
        return tareas;
    }

    public List<Tarea> filtrarPorEstado(boolean completadas) {
        List<Tarea> filtradas = new ArrayList<>();

        for (Tarea t : tareas) {
            if (t.isCompletada() == completadas) {
                filtradas.add(t);
            }
        }
        return filtradas;
    }

    public boolean marcarComoCompletada(int id) {
        for (Tarea t : tareas) {
            if (t.getId() == id) {
                t.marcarComoCompletada();
                return true;
            }
        }
        return false;
    }
}
